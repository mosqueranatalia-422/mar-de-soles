package com.Analisis.ApiAnalisisGastos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiAnalisisGastosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiAnalisisGastosApplication.class, args);
	}

}
