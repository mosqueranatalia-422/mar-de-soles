package com.Analisis.ApiAnalisisGastos.services;


import com.Analisis.ApiAnalisisGastos.models.expenses;
import com.Analisis.ApiAnalisisGastos.repository.iRepoExpenses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class expensesServices {

    @Autowired
    private iRepoExpenses expensesRepo;
    //Funcion para habilitar el guardado

    public expenses Guardargastos (expenses datos){
        return expensesRepo.save(datos);
    };
    //Funcion para habilitar el listado
    public List<expenses>Listar(){
        return expensesRepo.findAll();

    }
}
