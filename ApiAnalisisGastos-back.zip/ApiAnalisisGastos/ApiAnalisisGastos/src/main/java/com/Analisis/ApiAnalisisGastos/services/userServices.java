package com.Analisis.ApiAnalisisGastos.services;

import com.Analisis.ApiAnalisisGastos.models.users;
import com.Analisis.ApiAnalisisGastos.repository.iRepoUsers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class userServices {

    @Autowired
    private iRepoUsers userRepo;
    //Funcion para habilitar el guardado
    public users GuardarUsuario (users datos){
        return userRepo.save(datos);
    };
    //Funcion para habilitar el listado
    public List<users>Listar(){
        return userRepo.findAll();
    }
}
