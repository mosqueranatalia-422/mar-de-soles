package com.Analisis.ApiAnalisisGastos.controller;

import com.Analisis.ApiAnalisisGastos.models.users;

import com.Analisis.ApiAnalisisGastos.services.userServices;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

@RestController

@RequestMapping("api/v1/users")

public class userController {

    @Autowired

    private userServices ServicioUsuario;

    @PostMapping

    public ResponseEntity<?> ControlarGuardado(@RequestBody users Datos){

        return ResponseEntity.status(HttpStatus.OK)

                .body(ServicioUsuario.GuardarUsuario(Datos));

    }

    @GetMapping

    public ResponseEntity<?> ControlarListado(){

        return ResponseEntity.status(HttpStatus.OK)

                .body(ServicioUsuario.Listar());

    }

}
