package com.Analisis.ApiAnalisisGastos.controller;

import com.Analisis.ApiAnalisisGastos.models.expenses;
import com.Analisis.ApiAnalisisGastos.services.expensesServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/expenses")
public class expensesController {

    @Autowired
    private expensesServices ServicioGastos;

    @PostMapping
    public ResponseEntity<?> ControlarGuardado(@RequestBody expenses Datos){
        return ResponseEntity.status(HttpStatus.OK)
                .body(ServicioGastos.Guardargastos(Datos));
    }

    @GetMapping
    public ResponseEntity<?> ControlarListado(){
        return ResponseEntity.status(HttpStatus.OK)
                .body(ServicioGastos.Listar());
    }
}