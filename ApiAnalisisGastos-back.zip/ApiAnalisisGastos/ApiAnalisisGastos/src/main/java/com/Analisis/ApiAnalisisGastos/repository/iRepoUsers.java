package com.Analisis.ApiAnalisisGastos.repository;

import com.Analisis.ApiAnalisisGastos.models.users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface iRepoUsers extends JpaRepository<users, Integer> {
}
